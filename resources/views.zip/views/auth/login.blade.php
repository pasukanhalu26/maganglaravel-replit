<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — SIP Puskesmas Driyorejo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        *{box-sizing:border-box;margin:0;padding:0}
        html,body{height:100%;font-family:'Plus Jakarta Sans',sans-serif;overflow:hidden}

        /* === BACKGROUND === */
        body{
            background:linear-gradient(135deg,#021a10 0%,#032e1c 25%,#054a2c 50%,#032e1c 75%,#021a10 100%);
            position:relative;
        }

        /* Canvas for particles */
        #particleCanvas{position:fixed;inset:0;z-index:0;pointer-events:none}

        /* === FLOATING MEDICAL ICONS === */
        .med-bg{position:fixed;inset:0;z-index:1;pointer-events:none;overflow:hidden}
        .med-item{
            position:absolute;
            color:rgba(52,211,153,0.55);
            font-size:var(--s,2.5rem);
            bottom:-80px;
            left:var(--x,50%);
            animation:floatUp var(--d,15s) linear infinite;
            animation-delay:var(--dl,0s);
            filter:drop-shadow(0 0 15px rgba(16,185,129,0.5)) drop-shadow(0 0 30px rgba(5,150,105,0.25));
            text-shadow:0 0 20px rgba(16,185,129,0.4);
        }
        .med-item:nth-child(even){color:rgba(110,231,183,0.5)}
        .med-item:nth-child(3n){color:rgba(167,243,208,0.45)}

        @keyframes floatUp{
            0%{transform:translateY(0) rotate(0deg) scale(0.8);opacity:0}
            8%{opacity:1}
            20%{opacity:0.9}
            50%{transform:translateY(-55vh) rotate(180deg) scale(1.1);opacity:0.85}
            80%{opacity:0.9}
            92%{opacity:0.5}
            100%{transform:translateY(-115vh) rotate(360deg) scale(0.9);opacity:0}
        }

        /* === BLOBS === */
        .orb{position:fixed;border-radius:50%;filter:blur(80px);opacity:.4;z-index:0;animation:orbDrift 20s ease-in-out infinite alternate}
        .orb-1{width:500px;height:500px;background:radial-gradient(circle,#059669,transparent);top:-15%;left:-10%;animation-duration:22s}
        .orb-2{width:400px;height:400px;background:radial-gradient(circle,#10B981,transparent);bottom:-10%;right:-5%;animation-delay:-8s;animation-duration:18s}
        .orb-3{width:300px;height:300px;background:radial-gradient(circle,#047857,transparent);top:50%;left:60%;animation-delay:-14s;animation-duration:25s}

        @keyframes orbDrift{
            0%{transform:translate(0,0) scale(1)}
            33%{transform:translate(30px,40px) scale(1.1)}
            66%{transform:translate(-20px,20px) scale(.95)}
            100%{transform:translate(10px,-30px) scale(1.05)}
        }

        /* === WRAPPER === */
        .login-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1.5rem;position:relative;z-index:2}

        /* === GLASS CARD === */
        .glass-card{
            background:rgba(255,255,255,0.07);
            backdrop-filter:blur(20px) saturate(180%);
            -webkit-backdrop-filter:blur(20px) saturate(180%);
            border:1px solid rgba(16,185,129,0.25);
            border-radius:24px;
            width:100%;max-width:420px;
            padding:2.5rem 2.25rem;
            box-shadow:0 25px 50px rgba(0,0,0,0.5),0 0 80px rgba(5,150,105,0.15),inset 0 1px 0 rgba(255,255,255,0.1);
            animation:cardIn .8s cubic-bezier(.16,1,.3,1) forwards;
            opacity:0;transform:translateY(50px) scale(.96);
            position:relative;overflow:hidden;
        }
        .glass-card::before{
            content:'';position:absolute;top:0;left:0;right:0;height:3px;
            background:linear-gradient(90deg,transparent,#10B981,#059669,#10B981,transparent);
            background-size:300% 100%;animation:shimBar 4s linear infinite;
        }

        @keyframes cardIn{to{opacity:1;transform:translateY(0) scale(1)}}
        @keyframes shimBar{0%{background-position:300% 0}100%{background-position:-300% 0}}

        /* === BRAND === */
        .brand{text-align:center;margin-bottom:2rem}
        .logo-orbit{display:inline-block;position:relative;width:90px;height:90px;margin-bottom:1rem}
        .logo-orbit::before{
            content:'';position:absolute;inset:-6px;border-radius:50%;
            border:2px solid transparent;border-top-color:#10B981;border-right-color:#059669;
            animation:spin 3s linear infinite;
        }
        .logo-orbit::after{
            content:'';position:absolute;inset:-12px;border-radius:50%;
            border:1.5px solid transparent;border-bottom-color:#34D399;border-left-color:#10B981;
            animation:spin 5s linear infinite reverse;
        }
        @keyframes spin{to{transform:rotate(360deg)}}

        .logo-img{
            width:78px;height:78px;border-radius:50%;object-fit:cover;
            border:3px solid rgba(16,185,129,0.4);
            position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
            box-shadow:0 0 30px rgba(5,150,105,0.3);
            transition:transform .4s;z-index:1;
        }
        .logo-img:hover{transform:translate(-50%,-50%) scale(1.08)}

        .brand h1{font-size:1.5rem;font-weight:800;color:#fff;letter-spacing:-.5px;margin-bottom:.15rem;text-shadow:0 2px 10px rgba(0,0,0,.3)}
        .brand p{font-size:.85rem;color:rgba(255,255,255,.6);font-weight:500}

        .secure-badge{
            display:inline-flex;align-items:center;gap:.3rem;
            background:rgba(16,185,129,0.15);border:1px solid rgba(16,185,129,0.3);
            border-radius:50px;padding:.25rem .75rem;font-size:.72rem;
            color:#34D399;font-weight:600;margin-top:.6rem;
        }

        /* === FORM === */
        .field{position:relative;margin-bottom:1rem}
        .field input{
            width:100%;padding:.9rem 1rem .9rem 3rem;
            background:rgba(255,255,255,0.06);
            border:1.5px solid rgba(16,185,129,0.3);
            border-radius:14px;color:#fff;font-size:.95rem;
            transition:all .3s ease;outline:none;
            font-family:'Plus Jakarta Sans',sans-serif;
        }
        .field input::placeholder{color:rgba(255,255,255,.35)}
        .field input:focus{
            border-color:#10B981;
            box-shadow:0 0 0 4px rgba(16,185,129,.15),0 0 20px rgba(5,150,105,.1);
            background:rgba(255,255,255,0.1);
        }
        .field .fi{
            position:absolute;top:50%;left:1rem;transform:translateY(-50%);
            color:rgba(52,211,153,.6);font-size:1rem;transition:color .3s;pointer-events:none;
        }
        .field:focus-within .fi{color:#10B981}
        .field input[name="kode_id"]{font-family:'Courier New',monospace;letter-spacing:2px}

        .pw-eye{
            position:absolute;top:50%;right:1rem;transform:translateY(-50%);
            background:none;border:none;color:rgba(52,211,153,.5);cursor:pointer;
            font-size:.95rem;transition:color .3s;padding:0;
        }
        .pw-eye:hover{color:#10B981}

        /* === BUTTON === */
        .btn-login{
            display:flex;align-items:center;justify-content:center;gap:.5rem;
            width:100%;padding:.95rem;margin-top:.5rem;
            background:linear-gradient(135deg,#059669,#047857,#10B981);
            background-size:200% 200%;animation:gradShift 4s ease infinite;
            color:#fff;font-weight:700;font-size:1rem;
            border:none;border-radius:14px;cursor:pointer;
            box-shadow:0 8px 25px rgba(5,150,105,.5);
            transition:all .3s ease;position:relative;overflow:hidden;
        }
        .btn-login::before{
            content:'';position:absolute;top:50%;left:50%;width:0;height:0;
            background:rgba(255,255,255,.15);border-radius:50%;
            transition:width .6s,height .6s,top .6s,left .6s;
            transform:translate(-50%,-50%);
        }
        .btn-login:hover::before{width:300px;height:300px}
        .btn-login:hover{transform:translateY(-3px);box-shadow:0 12px 35px rgba(5,150,105,.6)}
        .btn-login:active{transform:translateY(0)}
        .btn-login .arrow{transition:transform .3s}
        .btn-login:hover .arrow{transform:translateX(5px)}

        @keyframes gradShift{
            0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}
        }

        /* === DIVIDER === */
        .sep{display:flex;align-items:center;gap:.75rem;margin:1.5rem 0;color:rgba(255,255,255,.25);font-size:.78rem}
        .sep::before,.sep::after{content:'';flex:1;height:1px;background:linear-gradient(90deg,transparent,rgba(16,185,129,.3),transparent)}

        /* === HELP === */
        .help{text-align:center}
        .help p{color:rgba(255,255,255,.45);font-size:.82rem;margin-bottom:.7rem;font-weight:500}
        .wa-btn{
            display:inline-flex;align-items:center;gap:.4rem;
            background:linear-gradient(135deg,#25D366,#128C7E);
            color:#fff;padding:.55rem 1.3rem;border-radius:50px;
            text-decoration:none;font-weight:600;font-size:.82rem;
            transition:all .3s;box-shadow:0 4px 15px rgba(37,211,102,.3);
        }
        .wa-btn:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(37,211,102,.4);color:#fff}

        /* === FOOTER === */
        .foot{position:fixed;bottom:1rem;left:0;right:0;text-align:center;font-size:.72rem;color:rgba(255,255,255,.25);z-index:2}

        /* === RESPONSIVE === */
        @media(max-width:480px){.glass-card{padding:2rem 1.5rem;margin:0 .5rem}}
    </style>
</head>
<body>
    <canvas id="particleCanvas"></canvas>

    <!-- Orbs -->
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>

    <!-- Floating medical icons -->
    <div class="med-bg" aria-hidden="true">
        <i class="fas fa-stethoscope med-item" style="--s:3.5rem;--x:5%;--d:14s;--dl:0s"></i>
        <i class="fas fa-heart-pulse med-item" style="--s:3rem;--x:15%;--d:19s;--dl:-5s"></i>
        <i class="fas fa-pills med-item" style="--s:2.5rem;--x:25%;--d:16s;--dl:-2s"></i>
        <i class="fas fa-briefcase-medical med-item" style="--s:4rem;--x:35%;--d:22s;--dl:-10s"></i>
        <i class="fas fa-hospital med-item" style="--s:5rem;--x:50%;--d:26s;--dl:-7s"></i>
        <i class="fas fa-microscope med-item" style="--s:3.5rem;--x:65%;--d:21s;--dl:-15s"></i>
        <i class="fas fa-user-doctor med-item" style="--s:4rem;--x:80%;--d:18s;--dl:-12s"></i>
        <i class="fas fa-dna med-item" style="--s:2.8rem;--x:90%;--d:17s;--dl:-3s"></i>
        <i class="fas fa-syringe med-item" style="--s:3rem;--x:12%;--d:20s;--dl:-8s"></i>
        <i class="fas fa-notes-medical med-item" style="--s:2.5rem;--x:42%;--d:15s;--dl:-4s"></i>
        <i class="fas fa-tablets med-item" style="--s:2.2rem;--x:72%;--d:24s;--dl:-6s"></i>
        <i class="fas fa-kit-medical med-item" style="--s:3.8rem;--x:58%;--d:23s;--dl:-9s"></i>
        <i class="fas fa-lungs med-item" style="--s:3rem;--x:95%;--d:18s;--dl:-11s"></i>
        <i class="fas fa-vial med-item" style="--s:2rem;--x:8%;--d:13s;--dl:-1s"></i>
        <i class="fas fa-thermometer med-item" style="--s:2.6rem;--x:32%;--d:20s;--dl:-13s"></i>
        <i class="fas fa-hand-holding-medical med-item" style="--s:3.2rem;--x:78%;--d:17s;--dl:-7s"></i>
    </div>

    <div class="login-wrap">
        <div class="glass-card">
            <div class="brand">
                <div class="logo-orbit">
                    <img src="https://img.favpng.com/9/7/20/puskesmas-regency-bengkulu-health-logo-png-favpng-QBnrLkYYPT1QdTbmGSNWRXN8J.jpg"
                         alt="Logo Puskesmas" class="logo-img"
                         onerror="this.src='https://ui-avatars.com/api/?name=SIP&background=059669&color=fff&rounded=true&size=128'">
                </div>
                <h1>SIP Driyorejo</h1>
                <p>Sistem Informasi Puskesmas</p>
                <div class="secure-badge"><i class="fas fa-shield-halved"></i> Akses Aman &amp; Terenkripsi</div>
            </div>

            <form action="{{ route('login') }}" method="POST" id="loginForm">
                @csrf
                <div class="field">
                    <i class="fas fa-id-badge fi"></i>
                    <input type="text" name="kode_id" id="kodeId" placeholder="Kode ID Login" value="{{ old('kode_id') }}" required autofocus autocomplete="off">
                </div>
                <div class="field">
                    <i class="fas fa-lock fi"></i>
                    <input type="password" name="password" id="pwInput" placeholder="Password" required autocomplete="current-password">
                    <button type="button" class="pw-eye" id="pwToggle" aria-label="Toggle password"><i class="fas fa-eye-slash" id="pwIcon"></i></button>
                </div>
                <button type="submit" class="btn-login" id="submitBtn">
                    <i class="fas fa-right-to-bracket"></i>
                    <span id="btnLabel">Masuk</span>
                    <i class="fas fa-arrow-right arrow"></i>
                </button>
            </form>

            <div class="sep">atau</div>

            <div class="help">
                <p>Belum punya akun? Hubungi Admin</p>
                <a href="https://wa.me/6285604099078?text=Halo%20Admin,%20saya%20ingin%20meminta%20akses%20akun%20SIP%20Puskesmas%20Driyorejo" target="_blank" rel="noopener" class="wa-btn">
                    <i class="fab fa-whatsapp"></i> Chat via WhatsApp
                </a>
            </div>
        </div>
    </div>

    <p class="foot">&copy; {{ date('Y') }} Puskesmas Driyorejo — SIP v2.0</p>

    <script>
    // ── Particles ──
    const cvs=document.getElementById('particleCanvas'),ctx=cvs.getContext('2d');
    let W,H,particles=[];
    function resize(){W=cvs.width=window.innerWidth;H=cvs.height=window.innerHeight}
    window.addEventListener('resize',resize);resize();

    class Particle{
        constructor(){this.reset()}
        reset(){
            this.x=Math.random()*W;this.y=Math.random()*H;
            this.r=Math.random()*2+.5;
            this.vx=(Math.random()-.5)*.4;this.vy=(Math.random()-.5)*.4;
            this.alpha=Math.random()*.5+.1;
            this.color=`hsla(${140+Math.random()*30},80%,70%,${this.alpha})`;
        }
        update(){
            this.x+=this.vx;this.y+=this.vy;
            if(this.x<0||this.x>W)this.vx*=-1;
            if(this.y<0||this.y>H)this.vy*=-1;
        }
        draw(){
            ctx.beginPath();ctx.arc(this.x,this.y,this.r,0,Math.PI*2);
            ctx.fillStyle=this.color;ctx.fill();
        }
    }

    for(let i=0;i<80;i++)particles.push(new Particle());

    function drawLines(){
        for(let i=0;i<particles.length;i++){
            for(let j=i+1;j<particles.length;j++){
                const dx=particles[i].x-particles[j].x,dy=particles[i].y-particles[j].y;
                const dist=Math.sqrt(dx*dx+dy*dy);
                if(dist<120){
                    ctx.beginPath();ctx.moveTo(particles[i].x,particles[i].y);
                    ctx.lineTo(particles[j].x,particles[j].y);
                    ctx.strokeStyle=`rgba(16,185,129,${.12*(1-dist/120)})`;
                    ctx.lineWidth=.5;ctx.stroke();
                }
            }
        }
    }

    function animateParticles(){
        ctx.clearRect(0,0,W,H);
        particles.forEach(p=>{p.update();p.draw()});
        drawLines();
        requestAnimationFrame(animateParticles);
    }
    animateParticles();

    // ── Password Toggle ──
    const pwI=document.getElementById('pwInput'),pwT=document.getElementById('pwToggle'),pwIc=document.getElementById('pwIcon');
    pwT.addEventListener('click',()=>{
        const show=pwI.type==='password';
        pwI.type=show?'text':'password';
        pwIc.className=show?'fas fa-eye':'fas fa-eye-slash';
    });

    // ── Form Submit ──
    document.getElementById('loginForm').addEventListener('submit',function(e){
        const btn=document.getElementById('submitBtn'),lbl=document.getElementById('btnLabel');
        btn.disabled=true;lbl.textContent='Memproses…';
        btn.querySelector('.arrow').className='fas fa-spinner fa-spin arrow';
    });

    // ── Error Popup (SweetAlert2) ──
    @if($errors->any())
    Swal.fire({
        icon:'error',
        title:'Login Gagal!',
        text:{!! json_encode($errors->first('kode_id') ?? 'Kode ID atau Password salah.') !!},
        confirmButtonColor:'#059669',
        background:'rgba(2,26,16,0.95)',
        color:'#fff',
        backdrop:'rgba(2,26,16,0.6)',
        customClass:{popup:'animate__animated animate__shakeX'}
    });
    @endif

    // ── Success Animation on page load ──
    @if(session('status'))
    Swal.fire({
        icon:'success',
        title:'Berhasil!',
        text:{!! json_encode(session('status')) !!},
        confirmButtonColor:'#059669',
        background:'rgba(2,26,16,0.95)',
        color:'#fff',
        timer:3000,
        timerProgressBar:true
    });
    @endif
    </script>
</body>
</html>