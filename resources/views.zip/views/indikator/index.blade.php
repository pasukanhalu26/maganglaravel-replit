@extends('layouts.admin')
@section('header', 'Master Data Indikator')
@section('content')
<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h5 class="fw-bold text-dark mb-0">Manajemen Indikator</h5>
        <div class="d-flex gap-2">
            <a href="{{ route('indikator.cetak') }}" target="_blank" class="btn btn-light border rounded-pill px-3 py-2"><i class="fas fa-file-pdf text-danger me-1"></i> Cetak</a>
            <a href="{{ route('indikator.create') }}" class="btn btn-green px-4"><i class="fas fa-plus-circle me-2"></i> Tambah Indikator</a>
        </div>
    </div>
    <div class="card-body p-4">

        <form action="{{ route('indikator.index') }}" method="GET" class="mb-4">
            <div class="row g-2">
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="fas fa-search text-muted"></i></span>
                        <input type="text" name="katakunci" class="form-control form-control-clean border-start-0" placeholder="Cari Indikator atau ID..." value="{{ Request::get('katakunci') }}">
                    </div>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-green w-100" type="submit">Filter</button>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover table-borderless align-middle">
                <thead class="text-center">
                    <tr>
                        <th>ID Indikator</th>
                        <th>ID Klaster</th>
                        <th>ID Program</th>
                        <th>Nama Indikator</th>
                        <th>Status</th>
                        <th>Created Date</th>
                        <th>Created By</th>
                        <th>Updated Date</th>
                        <th>Updated By</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($data as $i)
                    <tr>
                        <td class="text-center">
                            <div class="position-relative d-inline-block">
                                <span class="badge copy-id" data-id="{{ str_pad($i->id_indikator, 3, '0', STR_PAD_LEFT) }}" title="Klik untuk Copy ID" style="cursor: pointer; background: #6f42c1; font-family: monospace; font-size: 0.85rem; padding: 7px 12px; letter-spacing: 1px; transition: 0.3s;">
                                    #{{ str_pad($i->id_indikator, 3, '0', STR_PAD_LEFT) }}
                                </span>
                            </div>
                        </td>
                        <td class="text-center">
                            <div class="position-relative d-inline-block">
                                <span class="badge copy-id" data-id="{{ str_pad($i->id_klaster, 3, '0', STR_PAD_LEFT) }}" title="Klik untuk Copy ID Klaster" style="cursor: pointer; background: #a85d1d; font-family: monospace; font-size: 0.82rem; padding: 6px 10px; letter-spacing: 1px; transition: 0.3s;">
                                    #{{ str_pad($i->id_klaster, 3, '0', STR_PAD_LEFT) }}
                                </span>
                            </div>
                        </td>
                        <td class="text-center">
                            <div class="position-relative d-inline-block">
                                <span class="badge copy-id" data-id="{{ str_pad($i->id_program, 3, '0', STR_PAD_LEFT) }}" title="Klik untuk Copy ID Program" style="cursor: pointer; background: #0e7490; font-family: monospace; font-size: 0.82rem; padding: 6px 10px; letter-spacing: 1px; transition: 0.3s;">
                                    #{{ str_pad($i->id_program, 3, '0', STR_PAD_LEFT) }}
                                </span>
                            </div>
                        </td>
                        <td class="text-wrap"><strong>{{ $i->nama_indikator }}</strong></td>
                        <td class="text-center">
                            <span class="badge {{ $i->status == 1 ? 'bg-success' : 'bg-secondary' }}">
                                {{ $i->status == 1 ? 'Aktif' : 'Non-Aktif' }}
                            </span>
                        </td>
                        <td class="text-center"><small>{{ $i->created_at ? $i->created_at->format('d-m-Y H:i') : '-' }}</small></td>
                        <td class="text-center"><small>{{ $i->create_by ?? '-' }}</small></td>
                        <td class="text-center"><small>{{ $i->updated_at ? $i->updated_at->format('d-m-Y H:i') : '-' }}</small></td>
                        <td class="text-center"><small>{{ $i->update_by ?? '-' }}</small></td>
                        <td class="text-center">
                            <div class="d-flex justify-content-center gap-1">
                                <a href="{{ route('indikator.edit', $i->id_indikator) }}" class="btn btn-action btn-action-edit" title="Edit"><i class="fas fa-edit"></i></a>
                                <form action="{{ route('indikator.destroy', $i->id_indikator) }}" method="POST" class="form-delete"
                                    data-title="{{ $i->status == 1 ? 'Nonaktifkan Indikator?' : 'Aktifkan Indikator?' }}"
                                    data-text="{{ $i->status == 1 ? 'Indikator ini tidak akan bisa digunakan lagi.' : 'Indikator ini akan aktif kembali.' }}"
                                    data-color="{{ $i->status == 1 ? '#dc3545' : '#28A745' }}"
                                    data-confirm="{{ $i->status == 1 ? 'Ya, nonaktifkan' : 'Ya, aktifkan' }}">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-action {{ $i->status == 1 ? 'btn-action-delete' : 'btn-action-restore' }}" title="{{ $i->status == 1 ? 'Nonaktifkan' : 'Aktifkan' }}">
                                        <i class="fas {{ $i->status == 1 ? 'fa-ban' : 'fa-check' }}"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <div class="mt-4 d-flex justify-content-center">
            {{ $data->links() }}
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const copyBadges = document.querySelectorAll('.copy-id');
    
    copyBadges.forEach(badge => {
        badge.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const originalBg = this.style.background;
            
            navigator.clipboard.writeText(id).then(() => {
                const originalContent = this.innerHTML;
                this.innerHTML = '<i class="fas fa-check me-1"></i> Copied!';
                this.style.background = '#28a745';
                
                setTimeout(() => {
                    this.innerHTML = originalContent;
                    this.style.background = originalBg;
                }, 1500);
            });
        });
    });
});
</script>
@endsection