@extends('layouts.admin')
@section('header', 'Master Data Program')
@section('content')
<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h5 class="fw-bold text-dark mb-0">Manajemen Program</h5>
        <a href="{{ route('program.create') }}" class="btn btn-green px-4"><i class="fas fa-plus-circle me-2"></i> Tambah Program</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-borderless align-middle">
                <thead class="text-center">
                    <tr>
                        <th>ID Program</th>
                        <th>ID Klaster</th>
                        <th>Nama Program</th>
                        <th>Status</th>
                        <th>Created Date</th>
                        <th>Created By</th>
                        <th>Updated Date</th>
                        <th>Updated By</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($data as $key => $p)
                    <tr>
                        <td class="text-center">
                            <div class="position-relative d-inline-block">
                                <span class="badge copy-id" data-id="{{ str_pad($p->id_program, 3, '0', STR_PAD_LEFT) }}" title="Klik untuk Copy ID Program" style="cursor: pointer; background: #6f42c1; font-family: monospace; font-size: 0.85rem; padding: 7px 12px; letter-spacing: 1px; transition: 0.3s;">
                                    #{{ str_pad($p->id_program, 3, '0', STR_PAD_LEFT) }}
                                </span>
                            </div>
                        </td>
                        <td class="text-center">
                            <div class="position-relative d-inline-block">
                                <span class="badge copy-id" data-id="{{ str_pad($p->id_klaster, 3, '0', STR_PAD_LEFT) }}" title="Klik untuk Copy ID Klaster" style="cursor: pointer; background: #a85d1d; font-family: monospace; font-size: 0.82rem; padding: 6px 10px; letter-spacing: 1px; transition: 0.3s;">
                                    #{{ str_pad($p->id_klaster, 3, '0', STR_PAD_LEFT) }}
                                </span>
                            </div>
                        </td>
                        <td class="fw-semibold">{{ $p->nama_program }}</td>
                        <td class="text-center">
                            <span class="badge {{ $p->status == 1 ? 'bg-success' : 'bg-secondary' }}">{{ $p->status == 1 ? 'Aktif' : 'Non-Aktif' }}</span>
                        </td>
                        <td class="text-center small">{{ $p->created_at ? $p->created_at->format('d-m-Y H:i') : '-' }}</td>
                        <td class="text-center small">{{ $p->create_by ?? '-' }}</td>
                        <td class="text-center small">{{ $p->updated_at ? $p->updated_at->format('d-m-Y H:i') : '-' }}</td>
                        <td class="text-center small">{{ $p->update_by ?? '-' }}</td>
                        <td class="text-center">
                            <div class="d-flex justify-content-center gap-1">
                                <a href="{{ route('program.edit', $p->id_program) }}" class="btn btn-action btn-action-edit" title="Edit"><i class="fas fa-edit"></i></a>
                                <form action="{{ route('program.destroy', $p->id_program) }}" method="POST" class="form-delete" 
                                    data-title="{{ $p->status == 1 ? 'Nonaktifkan Program?' : 'Aktifkan Program?' }}" 
                                    data-text="{{ $p->status == 1 ? 'Program ini tidak akan bisa digunakan lagi.' : 'Program ini akan aktif kembali.' }}"
                                    data-color="{{ $p->status == 1 ? '#dc3545' : '#28A745' }}"
                                    data-confirm="{{ $p->status == 1 ? 'Ya, nonaktifkan' : 'Ya, aktifkan' }}">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-action {{ $p->status == 1 ? 'btn-action-delete' : 'btn-action-restore' }}" title="{{ $p->status == 1 ? 'Nonaktifkan' : 'Aktifkan' }}">
                                        <i class="fas {{ $p->status == 1 ? 'fa-ban' : 'fa-check' }}"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        {{ $data->links() }}
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const copyBadges = document.querySelectorAll('.copy-id');
    
    copyBadges.forEach(badge => {
        badge.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const originalBg = this.style.background;
            
            navigator.clipboard.writeText(id).then(() => {
                const originalContent = this.innerHTML;
                this.innerHTML = '<i class="fas fa-check me-1"></i> Copied!';
                this.style.background = '#28a745';
                
                setTimeout(() => {
                    this.innerHTML = originalContent;
                    this.style.background = originalBg;
                }, 1500);
            });
        });
    });
});
</script>
@endsection