@extends('layouts.admin')

@section('header', 'Dashboard Overview')

@section('content')
<style>
    /* Welcome Banner */
    .welcome-banner {
        background: linear-gradient(135deg, var(--accent-green), #047857);
        border-radius: 20px;
        padding: 30px 40px;
        color: white;
        position: relative;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(112, 55, 153, 0.2);
    }
    .welcome-banner::after {
        content: '';
        position: absolute;
        top: -50px;
        right: -50px;
        width: 200px;
        height: 200px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50%;
    }
    
    /* Modern Stat Cards */
    .stat-card-modern {
        background: #fff;
        border-radius: 20px;
        padding: 25px;
        border: none;
        position: relative;
        overflow: hidden;
        transition: all 0.3s ease;
        box-shadow: 0 5px 20px rgba(0,0,0,0.03);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        min-height: 140px;
    }
    .stat-card-modern:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.08);
    }
    .stat-icon-wrapper {
        width: 50px;
        height: 50px;
        border-radius: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        margin-bottom: 15px;
    }
    .stat-value {
        font-size: 2rem;
        font-weight: 800;
        color: var(--text-main);
        margin-bottom: 0;
        line-height: 1;
    }
    .stat-title {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--text-muted);
        margin-top: 5px;
    }
    
    /* Chart Card */
    .chart-card {
        background: #fff;
        border-radius: 20px;
        padding: 25px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.03);
        border: none;
    }
    
    /* Colors */
    .icon-blue { background: rgba(52, 152, 219, 0.1); color: #3498db; }
    .icon-green { background: rgba(5, 150, 105, 0.1); color: var(--accent-green); }
    .icon-green { background: rgba(46, 204, 113, 0.1); color: #2ecc71; }
    .icon-orange { background: rgba(230, 126, 34, 0.1); color: #e67e22; }
</style>

<!-- Welcome Banner -->
<div class="row mb-4">
    <div class="col-12">
        <div class="welcome-banner d-flex align-items-center justify-content-between flex-wrap">
            <div>
                <h3 class="fw-bold mb-2">Selamat Datang, {{ str_replace('_', ' ', ucwords(Auth::user()->role)) }}! 👋</h3>
                <p class="mb-0 opacity-75">Berikut adalah ringkasan kinerja dan data capaian Puskesmas Driyorejo hari ini.</p>
            </div>
            <div class="mt-3 mt-md-0">
                <p class="mb-0 fw-bold"><i class="far fa-calendar-alt me-2"></i> {{ date('d M Y') }}</p>
            </div>
        </div>
    </div>
</div>

<!-- 4 Stat Cards -->
<div class="row g-4 mb-4">
    <div class="col-md-3 col-sm-6">
        <div class="stat-card-modern">
            <div class="stat-icon-wrapper icon-blue">
                <i class="fas fa-map-marked-alt"></i>
            </div>
            <div>
                <h2 class="stat-value">{{ $total_desa ?? 0 }}</h2>
                <div class="stat-title">Total Desa Bina</div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6">
        <div class="stat-card-modern">
            <div class="stat-icon-wrapper icon-green">
                <i class="fas fa-layer-group"></i>
            </div>
            <div>
                <h2 class="stat-value">{{ $total_program ?? 0 }}</h2>
                <div class="stat-title">Total Program</div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6">
        <div class="stat-card-modern">
            <div class="stat-icon-wrapper icon-orange">
                <i class="fas fa-file-waveform"></i>
            </div>
            <div>
                <h2 class="stat-value">{{ $total_indikator ?? 0 }}</h2>
                <div class="stat-title">Indikator Kinerja</div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6">
        <div class="stat-card-modern">
            <div class="stat-icon-wrapper icon-green">
                <i class="fas fa-chart-line"></i>
            </div>
            <div>
                <h2 class="stat-value">{{ $total_capaian ?? 0 }}</h2>
                <div class="stat-title">Data Capaian</div>
            </div>
        </div>
    </div>
</div>

<!-- Chart Section Row 1 -->
<div class="row g-4 mb-4">
    <div class="col-md-8">
        <div class="chart-card h-100">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="fw-bold mb-0 text-dark">Tren Data Capaian (Per Bulan)</h5>
                <a href="{{ route('capaian.index') }}" class="btn btn-sm btn-light text-green rounded-pill px-3 fw-bold">Detail Data <i class="fas fa-arrow-right ms-1"></i></a>
            </div>
            <div style="height: 300px;">
                <canvas id="trenBulanChart"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="chart-card h-100">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="fw-bold mb-0 text-dark">Program per Klaster</h5>
                <a href="{{ route('program.index') }}" class="btn btn-sm btn-light text-green rounded-pill px-3 fw-bold">Lihat Semua <i class="fas fa-arrow-right ms-1"></i></a>
            </div>
            <div style="height: 300px;">
                <canvas id="klasterChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Chart Section Row 2 -->
<div class="row mb-5">
    <div class="col-12">
        <div class="chart-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="fw-bold mb-0 text-dark">Rata-rata Nilai Capaian per Desa</h5>
                <a href="{{ route('capaian.index') }}" class="btn btn-sm btn-light text-green rounded-pill px-3 fw-bold">Detail Data <i class="fas fa-arrow-right ms-1"></i></a>
            </div>
            <div style="height: 350px;">
                <canvas id="capaianChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Import Chart.js dari CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 1. Chart Rata-rata Capaian per Desa (Bar Chart)
        const ctxCapaian = document.getElementById('capaianChart').getContext('2d');
        const labelsDesa = {!! json_encode($label_grafik ?? []) !!};
        const dataDesa = {!! json_encode($data_grafik ?? []) !!};
        
        let gradientBar = ctxCapaian.createLinearGradient(0, 0, 0, 400);
        gradientBar.addColorStop(0, 'rgba(112, 55, 153, 0.8)');
        gradientBar.addColorStop(1, 'rgba(112, 55, 153, 0.2)');

        new Chart(ctxCapaian, {
            type: 'bar',
            data: {
                labels: labelsDesa,
                datasets: [{
                    label: 'Rata-rata Nilai Capaian',
                    data: dataDesa,
                    backgroundColor: gradientBar,
                    borderColor: 'rgba(112, 55, 153, 1)',
                    borderWidth: 1,
                    borderRadius: 8,
                    barPercentage: 0.6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#fff', titleColor: '#333', bodyColor: '#666',
                        borderColor: '#eee', borderWidth: 1, padding: 10, displayColors: false
                    }
                },
                scales: {
                    y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)', drawBorder: false } },
                    x: { grid: { display: false, drawBorder: false } }
                }
            }
        });

        // 2. Chart Tren Data Capaian per Bulan (Line Chart)
        const ctxTren = document.getElementById('trenBulanChart').getContext('2d');
        const labelsBulan = {!! json_encode($label_bulan ?? []) !!};
        const dataBulan = {!! json_encode($data_bulan ?? []) !!};

        let gradientLine = ctxTren.createLinearGradient(0, 0, 0, 400);
        gradientLine.addColorStop(0, 'rgba(52, 152, 219, 0.4)');
        gradientLine.addColorStop(1, 'rgba(52, 152, 219, 0.0)');

        new Chart(ctxTren, {
            type: 'line',
            data: {
                labels: labelsBulan,
                datasets: [{
                    label: 'Jumlah Capaian Ditambahkan',
                    data: dataBulan,
                    borderColor: '#3498db',
                    backgroundColor: gradientLine,
                    borderWidth: 3,
                    pointBackgroundColor: '#fff',
                    pointBorderColor: '#3498db',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    fill: true,
                    tension: 0.4 // membuat garis melengkung smooth
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#fff', titleColor: '#333', bodyColor: '#666',
                        borderColor: '#eee', borderWidth: 1, padding: 10, displayColors: false
                    }
                },
                scales: {
                    y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)', drawBorder: false }, ticks: { stepSize: 1 } },
                    x: { grid: { display: false, drawBorder: false } }
                }
            }
        });

        // 3. Chart Sebaran Program per Klaster (Doughnut Chart)
        const ctxKlaster = document.getElementById('klasterChart').getContext('2d');
        const labelsKlaster = {!! json_encode($label_klaster ?? []) !!};
        const dataKlaster = {!! json_encode($data_klaster ?? []) !!};

        new Chart(ctxKlaster, {
            type: 'doughnut',
            data: {
                labels: labelsKlaster,
                datasets: [{
                    data: dataKlaster,
                    backgroundColor: [
                        '#059669', // accent-green
                        '#3498db', // blue
                        '#2ecc71', // green
                        '#e67e22', // orange
                        '#e74c3c', // red
                        '#9b59b6'  // amethyst
                    ],
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { padding: 20, usePointStyle: true, pointStyle: 'circle' }
                    },
                    tooltip: {
                        backgroundColor: '#fff', titleColor: '#333', bodyColor: '#666',
                        borderColor: '#eee', borderWidth: 1, padding: 10
                    }
                }
            }
        });
    });
</script>
@endsection