@extends('layouts.admin')
@section('header', 'Edit Capaian')
@section('content')
<div class="row justify-content-center">
    <div class="col-md-9">
        <div class="modern-form-card">
            <div class="modern-form-header d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-edit me-2"></i>Edit Data Capaian</h6>
                <a href="{{ route('capaian.index') }}" class="btn btn-sm btn-light text-green rounded-pill px-3 shadow-sm"><i class="fas fa-arrow-left me-1"></i> Kembali</a>
            </div>
            <div class="modern-form-body">

                @if ($errors->any())
                    <div class="alert alert-danger border-0 rounded-3 mb-4">
                        <ul class="mb-0 small">@foreach ($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
                    </div>
                @endif

                <form action="{{ route('capaian.update', $capaian->id_capaian) }}" method="POST">
                    @csrf @method('PUT')

                    <div class="mb-4">
                        <label class="text-muted small fw-bold mb-1">Pilih Klaster</label>
                        <select id="filter_klaster" class="form-select form-select-modern select-searchable">
                            @foreach($klasters as $k)
                                <option value="{{ $k->id_klaster }}" {{ $capaian->target->id_klaster == $k->id_klaster ? 'selected' : '' }}>{{ $k->nama_klaster }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="text-muted small fw-bold mb-1">Pilih Program</label>
                        <select id="filter_program" class="form-select form-select-modern select-searchable">
                            @if($capaian->target && $capaian->target->program)
                                <option value="{{ $capaian->target->id_program }}" selected>{{ $capaian->target->program->nama_program }}</option>
                            @endif
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="text-muted small fw-bold mb-1">Pilih Indikator</label>
                        <select id="filter_indikator" class="form-select form-select-modern select-searchable">
                            @if($capaian->target && $capaian->target->indikator)
                                <option value="{{ $capaian->target->id_indikator }}" selected>{{ Str::limit($capaian->target->indikator->nama_indikator, 100) }}</option>
                            @endif
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="text-muted small fw-bold mb-1">Pilih Tahun (dari data Target)</label>
                        <select name="id_target" id="id_target" class="form-select form-select-modern select-searchable" required>
                            @if($capaian->target)
                                <option value="{{ $capaian->id_target }}" selected>{{ $capaian->target->periode }}</option>
                            @endif
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="text-muted small fw-bold mb-1">Pilih Bulan</label>
                        <select name="bulan" class="form-select form-select-modern select-searchable" required>
                            @php
                                $bulans = [1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',5=>'Mei',6=>'Juni',
                                          7=>'Juli',8=>'Agustus',9=>'September',10=>'Oktober',11=>'November',12=>'Desember'];
                            @endphp
                            @foreach($bulans as $num => $name)
                                <option value="{{ $num }}" {{ $capaian->bulan == $num ? 'selected' : '' }}>{{ $num }} - {{ $name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-5">
                        <label class="text-muted small fw-bold mb-1">Pilih Desa</label>
                        <select name="id_desa" class="form-select form-select-modern select-searchable" required>
                            @foreach($desas as $d)
                                <option value="{{ $d->id_desa }}" {{ $capaian->id_desa == $d->id_desa ? 'selected' : '' }}>
                                    {{ $d->nama_desa }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-5">
                        <label class="text-muted small fw-bold mb-1">Capaian Bulan (Nilai/Angka)</label>
                        <div class="input-group">
                            <button type="button" class="btn btn-outline-secondary px-3" onclick="stepValue('capaian_bulan', -1)">
                                <i class="fas fa-minus"></i>
                            </button>
                            <input type="number" name="capaian_bulan" id="capaian_bulan" class="form-control form-control-modern text-center"
                                value="{{ $capaian->capaian_bulan }}" placeholder="0" min="0" required style="font-size: 1.1rem;">
                            <button type="button" class="btn btn-outline-secondary px-3" onclick="stepValue('capaian_bulan', 1)">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6"><a href="{{ route('capaian.index') }}" class="btn-modern-cancel">Batal</a></div>
                        <div class="col-md-6"><button type="submit" class="btn-modern-save"><i class="fas fa-save me-2"></i>Update Capaian</button></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function stepValue(id, delta) {
    const el = document.getElementById(id);
    let val = parseInt(el.value) || 0;
    val += delta;
    if (val < 0) val = 0;
    el.value = val;
}

document.addEventListener('DOMContentLoaded', function() {
    const filterKlaster = document.getElementById('filter_klaster');
    const filterProgram = document.getElementById('filter_program');
    const filterIndikator = document.getElementById('filter_indikator');
    const selectTarget = document.getElementById('id_target'); // Label: TAHUN

    let progTomSelect = null, indTomSelect = null, targTomSelect = null;

    setTimeout(() => {
        if(filterProgram.tomselect) progTomSelect = filterProgram.tomselect;
        if(filterIndikator.tomselect) indTomSelect = filterIndikator.tomselect;
        if(selectTarget.tomselect) targTomSelect = selectTarget.tomselect;
    }, 100);

    // 1. Klaster -> Program
    filterKlaster.addEventListener('change', function() {
        const idKlaster = this.value;
        if(progTomSelect) { progTomSelect.clearOptions(); progTomSelect.clear(); }
        if(indTomSelect) { indTomSelect.clearOptions(); indTomSelect.clear(); }
        if(targTomSelect) { targTomSelect.clearOptions(); targTomSelect.clear(); }

        if(idKlaster) {
            fetch(`/api/programs/${idKlaster}`)
                .then(res => res.json())
                .then(data => {
                    if(progTomSelect) {
                        data.forEach(p => progTomSelect.addOption({value: p.id_program, text: p.nama_program}));
                        progTomSelect.refreshOptions(false);
                    }
                });
        }
    });

    // 2. Program -> Indikator
    filterProgram.addEventListener('change', function() {
        const idProgram = this.value;
        if(indTomSelect) { indTomSelect.clearOptions(); indTomSelect.clear(); }
        if(targTomSelect) { targTomSelect.clearOptions(); targTomSelect.clear(); }

        if(idProgram) {
            fetch(`/api/indikators/${idProgram}`)
                .then(res => res.json())
                .then(data => {
                    if(indTomSelect) {
                        data.forEach(i => indTomSelect.addOption({value: i.id_indikator, text: i.nama_indikator}));
                        indTomSelect.refreshOptions(false);
                    }
                });
        }
    });

    // 3. Indikator -> Target (Tahun)
    filterIndikator.addEventListener('change', function() {
        const idIndikator = this.value;
        if(targTomSelect) { targTomSelect.clearOptions(); targTomSelect.clear(); }

        if(idIndikator) {
            fetch(`/api/targets/${idIndikator}`)
                .then(res => res.json())
                .then(data => {
                    if(targTomSelect) {
                        data.forEach(t => {
                            // Cukup tampilkan tahunnya, tapi value-nya tetap id_target
                            targTomSelect.addOption({
                                value: t.id_target, 
                                text: t.periode
                            });
                        });
                        targTomSelect.refreshOptions(false);
                    }
                });
        }
    });
});
</script>
@endsection