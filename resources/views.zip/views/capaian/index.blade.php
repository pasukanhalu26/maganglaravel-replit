@extends('layouts.admin')
@section('header', 'Data Capaian')
@section('content')
<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h5 class="fw-bold text-dark mb-0">Manajemen Capaian Bulanan</h5>
        <div class="d-flex gap-2">
            <a href="{{ route('capaian.cetak') }}" class="btn btn-light border rounded-pill px-3 py-2"><i class="fas fa-file-pdf text-danger me-1"></i> Cetak PDF</a>
            <a href="{{ route('capaian.create') }}" class="btn btn-green px-4"><i class="fas fa-plus-circle me-2"></i> Tambah Data</a>
        </div>
    </div>
    <div class="card-body p-4">
        <form action="{{ route('capaian.index') }}" method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="katakunci" class="form-control form-control-clean" placeholder="Cari Desa, Indikator, Bulan..." value="{{ Request::get('katakunci') }}">
                <button class="btn btn-green" type="submit"><i class="fas fa-search"></i> Cari</button>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover table-borderless align-middle">
                <thead class="text-center">
                    <tr>
                        <th>ID Capaian</th>
                        <th>Target Info</th>
                        <th>Desa</th>
                        <th>Bulan</th>
                        <th>Periode</th>
                        <th>Capaian Bulan</th>
                        <th>Target Tahunan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($data as $key => $item)
                    <tr>
                        <td class="text-center">
                            <span class="badge" style="background: linear-gradient(135deg, #703799, #5D2E80); font-family: monospace; font-size: 0.85rem; padding: 7px 12px; letter-spacing: 1px;">
                                #{{ str_pad($item->id_capaian, 3, '0', STR_PAD_LEFT) }}
                            </span>
                        </td>
                        <td>
                            @if($item->target)
                                <div class="small fw-bold text-dark">{{ Str::limit($item->target->indikator->nama_indikator ?? 'Indikator tidak ada', 40) }}</div>
                                <div class="mt-1 d-flex gap-1">
                                    <span class="badge" style="background: linear-gradient(135deg, #703799, #5D2E80); font-size: 0.65rem;">T-{{ str_pad($item->id_target,3,'0',STR_PAD_LEFT) }}</span>
                                    <span class="badge" style="background: linear-gradient(135deg, #92400e, #b45309); font-size: 0.65rem;">K-{{ str_pad($item->target->id_klaster,3,'0',STR_PAD_LEFT) }}</span>
                                    <span class="badge" style="background: linear-gradient(135deg, #0e7490, #0891b2); font-size: 0.65rem;">P-{{ str_pad($item->target->id_program,3,'0',STR_PAD_LEFT) }}</span>
                                </div>
                            @else
                                <span class="text-muted small">Data Target Dihapus</span>
                            @endif
                        </td>
                        <td class="text-center fw-bold">{{ $item->desa->nama_desa ?? '-' }}</td>
                        <td class="text-center">
                            @php
                                $bulans = [1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',5=>'Mei',6=>'Juni',
                                          7=>'Juli',8=>'Agustus',9=>'September',10=>'Oktober',11=>'November',12=>'Desember'];
                            @endphp
                            <span class="badge bg-light text-dark border">{{ $bulans[$item->bulan] ?? $item->bulan }}</span>
                        </td>
                        <td class="text-center">{{ $item->target->periode ?? '-' }}</td>
                        <td class="text-center">
                            <span class="fw-bold fs-6" style="color: var(--accent-green);">{{ number_format($item->capaian_bulan) }}</span>
                        </td>
                        <td class="text-center">
                            <span class="text-muted small">{{ number_format($item->target->target_tahunan ?? 0) }}</span>
                        </td>
                        <td class="text-center">
                            <span class="badge {{ $item->status == 1 ? 'bg-success' : 'bg-secondary' }}">
                                {{ $item->status == 1 ? 'Aktif' : 'Non-Aktif' }}
                            </span>
                        </td>
                        <td class="text-center">
                            <div class="d-flex justify-content-center gap-1">
                                <a href="{{ route('capaian.edit', $item->id_capaian) }}" class="btn btn-action btn-action-edit" title="Edit"><i class="fas fa-edit"></i></a>
                                <form action="{{ route('capaian.destroy', $item->id_capaian) }}" method="POST" class="form-delete" 
                                    data-title="{{ $item->status == 1 ? 'Nonaktifkan Capaian?' : 'Aktifkan Capaian?' }}" 
                                    data-text="{{ $item->status == 1 ? 'Data capaian ini tidak akan dihitung.' : 'Data capaian ini akan aktif kembali.' }}"
                                    data-color="{{ $item->status == 1 ? '#dc3545' : '#28A745' }}"
                                    data-confirm="{{ $item->status == 1 ? 'Ya, nonaktifkan' : 'Ya, aktifkan' }}">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-action {{ $item->status == 1 ? 'btn-action-delete' : 'btn-action-restore' }}" title="{{ $item->status == 1 ? 'Nonaktifkan' : 'Aktifkan' }}">
                                        <i class="fas {{ $item->status == 1 ? 'fa-ban' : 'fa-check' }}"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        {{ $data->links() }}
    </div>
</div>
@endsection